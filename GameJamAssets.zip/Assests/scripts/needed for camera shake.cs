///needed for camerashake

//after behaviour that you want to trigger camera shake
// public CameraShake CameraShake;

// //place inside curly brackets if statement
// StartCoroutine(cameraShake.Shake(.15f, .4f));


// //right click on camera and create empty, call it camera holder, 
// //reset the transform,
// //drag it out and above camera,
// //attach main camera to cameraholder,